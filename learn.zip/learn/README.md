# ethereum-quickstart
Ethereum mining clients, tools and scripts

clients:
- ethminer 0.18
- phoenixminer 5.1c

tools:
- amdvbflash 4.69 (atiflash)
