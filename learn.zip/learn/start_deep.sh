#
# Example shell file for starting PhoenixMiner to mine ETH
#
# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./deep/deep -pool us1.ethermine.org:4444 -wal 0x4144725b0FcD734fAF2Ca3b0641c82Da8fcCd727.worker -proto 3 -gt 7
